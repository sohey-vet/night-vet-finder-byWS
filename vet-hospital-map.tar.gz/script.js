// Global variables
let map;
let service;
let infoWindow;
let currentLocation;
let markers = [];

// DOM elements
const currentLocationBtn = document.getElementById('currentLocationBtn');
const locationNameBtn = document.getElementById('locationNameBtn');
const locationNameInput = document.getElementById('locationNameInput');
const locationName = document.getElementById('locationName');
const searchBtn = document.getElementById('searchBtn');
const loadingArea = document.getElementById('loadingArea');
const errorArea = document.getElementById('errorArea');
const errorMessage = document.getElementById('errorMessage');
const retryBtn = document.getElementById('retryBtn');
const resultsArea = document.getElementById('resultsArea');
const hospitalsList = document.getElementById('hospitalsList');
const shareBtn = document.getElementById('shareBtn');
const feedbackBtn = document.getElementById('feedbackBtn');

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize Google Maps
function initMap() {
    // Initialize map (will be updated with actual location later)
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 15,
        center: { lat: 35.6762, lng: 139.6503 }, // Tokyo default
        styles: [
            {
                featureType: 'poi.business',
                stylers: [{ visibility: 'off' }]
            }
        ]
    });

    service = new google.maps.places.PlacesService(map);
    infoWindow = new google.maps.InfoWindow();
}

// Initialize app functionality
function initializeApp() {
    // Search method toggle
    currentLocationBtn.addEventListener('click', function() {
        setSearchMethod('current');
    });

    locationNameBtn.addEventListener('click', function() {
        setSearchMethod('name');
    });

    // Search button
    searchBtn.addEventListener('click', function() {
        performSearch();
    });

    // Retry button
    retryBtn.addEventListener('click', function() {
        hideError();
        performSearch();
    });

    // Share button
    shareBtn.addEventListener('click', function() {
        shareToTwitter();
    });

    // Feedback button
    feedbackBtn.addEventListener('click', function() {
        openFeedbackForm();
    });

    // Enter key for location name input
    locationName.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
}

// Set search method (current location or by name)
function setSearchMethod(method) {
    if (method === 'current') {
        currentLocationBtn.classList.add('active');
        locationNameBtn.classList.remove('active');
        locationNameInput.style.display = 'none';
    } else {
        currentLocationBtn.classList.remove('active');
        locationNameBtn.classList.add('active');
        locationNameInput.style.display = 'block';
        locationName.focus();
    }
}

// Perform search based on selected method
function performSearch() {
    hideResults();
    hideError();
    showLoading();

    if (currentLocationBtn.classList.contains('active')) {
        searchByCurrentLocation();
    } else {
        searchByLocationName();
    }
}

// Search by current location
function searchByCurrentLocation() {
    if (!navigator.geolocation) {
        showError('位置情報がサポートされていません。地名で検索してください。');
        return;
    }

    navigator.geolocation.getCurrentPosition(
        function(position) {
            currentLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            map.setCenter(currentLocation);
            searchHospitals(currentLocation);
        },
        function(error) {
            let errorMsg = '位置情報の取得に失敗しました。';
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMsg = '位置情報の使用が許可されていません。ブラウザの設定を確認してください。';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMsg = '位置情報が取得できません。地名で検索してください。';
                    break;
                case error.TIMEOUT:
                    errorMsg = '位置情報の取得がタイムアウトしました。もう一度お試しください。';
                    break;
            }
            showError(errorMsg);
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000
        }
    );
}

// Search by location name
function searchByLocationName() {
    const location = locationName.value.trim();
    if (!location) {
        showError('地名を入力してください。');
        return;
    }

    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: location }, function(results, status) {
        if (status === 'OK' && results[0]) {
            currentLocation = results[0].geometry.location;
            map.setCenter(currentLocation);
            searchHospitals(currentLocation);
        } else {
            showError('指定された地名が見つかりません。別の地名をお試しください。');
        }
    });
}

// Search for hospitals using Places API
function searchHospitals(location) {
    clearMarkers();

    const request = {
        location: location,
        radius: 10000, // 10km radius
        keyword: '夜間救急 動物病院',
        type: 'veterinary_care',
        openNow: true
    };

    service.nearbySearch(request, function(results, status) {
        if (status === google.maps.places.PlacesServiceStatus.OK && results.length > 0) {
            // Sort by distance
            results.sort((a, b) => {
                const distanceA = calculateDistance(location, a.geometry.location);
                const distanceB = calculateDistance(location, b.geometry.location);
                return distanceA - distanceB;
            });

            displayResults(results, location);
        } else {
            // Try alternative search
            const alternativeRequest = {
                location: location,
                radius: 15000, // Expand radius
                keyword: '動物病院 休日診療',
                type: 'veterinary_care'
            };

            service.nearbySearch(alternativeRequest, function(altResults, altStatus) {
                if (altStatus === google.maps.places.PlacesServiceStatus.OK && altResults.length > 0) {
                    altResults.sort((a, b) => {
                        const distanceA = calculateDistance(location, a.geometry.location);
                        const distanceB = calculateDistance(location, b.geometry.location);
                        return distanceA - distanceB;
                    });
                    displayResults(altResults, location);
                } else {
                    showError('この周辺には現在診療中の夜間救急病院が見つかりませんでした。検索範囲を広げるか、地域の動物医師会などにご確認ください。');
                }
            });
        }
    });
}

// Display search results
function displayResults(places, userLocation) {
    hideLoading();
    showResults();

    // Clear previous results
    hospitalsList.innerHTML = '';

    // Add markers and create hospital cards
    places.forEach((place, index) => {
        // Add marker to map
        const marker = new google.maps.Marker({
            position: place.geometry.location,
            map: map,
            title: place.name,
            icon: {
                url: 'data:image/svg+xml;base64,' + btoa(`
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
                        <circle cx="16" cy="16" r="15" fill="#dc3545" stroke="white" stroke-width="2"/>
                        <text x="16" y="20" font-family="Arial" font-size="16" font-weight="bold" text-anchor="middle" fill="white">+</text>
                    </svg>
                `),
                scaledSize: new google.maps.Size(32, 32)
            }
        });

        markers.push(marker);

        // Add click listener for marker
        marker.addListener('click', function() {
            infoWindow.setContent(`
                <div style="max-width: 200px;">
                    <h3 style="margin: 0 0 8px 0; font-size: 16px;">${place.name}</h3>
                    <p style="margin: 0; font-size: 14px; color: #666;">${place.vicinity}</p>
                </div>
            `);
            infoWindow.open(map, marker);
        });

        // Create hospital card
        const hospitalCard = createHospitalCard(place, userLocation);
        hospitalsList.appendChild(hospitalCard);
    });

    // Adjust map bounds to show all markers
    if (markers.length > 0) {
        const bounds = new google.maps.LatLngBounds();
        bounds.extend(userLocation);
        markers.forEach(marker => bounds.extend(marker.getPosition()));
        map.fitBounds(bounds);
    }
}

// Create hospital card element
function createHospitalCard(place, userLocation) {
    const distance = calculateDistance(userLocation, place.geometry.location);
    const distanceText = distance < 1 ? `約${Math.round(distance * 1000)}m` : `約${distance.toFixed(1)}km`;

    const card = document.createElement('div');
    card.className = 'hospital-card';
    
    card.innerHTML = `
        <div class="hospital-name">${place.name}</div>
        <div class="hospital-distance">${distanceText}</div>
        <div class="hospital-address">${place.vicinity}</div>
        ${place.formatted_phone_number ? `<div class="hospital-phone">📞 ${place.formatted_phone_number}</div>` : ''}
        <div class="hospital-actions">
            ${place.formatted_phone_number ? 
                `<button class="hospital-action-btn phone-btn" onclick="callHospital('${place.formatted_phone_number}')">
                    📞 電話をかける
                </button>` : ''
            }
            <button class="hospital-action-btn map-btn" onclick="openInMaps(${place.geometry.location.lat()}, ${place.geometry.location.lng()}, '${encodeURIComponent(place.name)}')">
                🗺️ 地図アプリで開く
            </button>
        </div>
    `;

    return card;
}

// Calculate distance between two points
function calculateDistance(pos1, pos2) {
    const lat1 = typeof pos1.lat === 'function' ? pos1.lat() : pos1.lat;
    const lng1 = typeof pos1.lng === 'function' ? pos1.lng() : pos1.lng;
    const lat2 = typeof pos2.lat === 'function' ? pos2.lat() : pos2.lat;
    const lng2 = typeof pos2.lng === 'function' ? pos2.lng() : pos2.lng;

    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}

// Call hospital
function callHospital(phoneNumber) {
    window.location.href = `tel:${phoneNumber}`;
}

// Open in maps app
function openInMaps(lat, lng, name) {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAndroid = /Android/.test(navigator.userAgent);
    
    if (isIOS) {
        window.open(`maps://maps.google.com/maps?daddr=${lat},${lng}&amp;ll=`);
    } else if (isAndroid) {
        window.open(`geo:${lat},${lng}?q=${lat},${lng}(${name})`);
    } else {
        window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`);
    }
}

// Clear all markers
function clearMarkers() {
    markers.forEach(marker => marker.setMap(null));
    markers = [];
}

// UI state management functions
function showLoading() {
    loadingArea.style.display = 'block';
}

function hideLoading() {
    loadingArea.style.display = 'none';
}

function showError(message) {
    hideLoading();
    errorMessage.textContent = message;
    errorArea.style.display = 'block';
}

function hideError() {
    errorArea.style.display = 'none';
}

function showResults() {
    resultsArea.style.display = 'block';
}

function hideResults() {
    resultsArea.style.display = 'none';
}

// Share to Twitter
function shareToTwitter() {
    const text = '夜間救急どうぶつ病院マップで緊急時の動物病院を検索しました！';
    const url = window.location.href;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank');
}

// Open feedback form
function openFeedbackForm() {
    // This would typically open a feedback form or redirect to a feedback page
    alert('ご意見・ご感想をお聞かせください。\n\n情報が古い場合や改善点がございましたら、お知らせください。');
}